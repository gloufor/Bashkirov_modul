﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BashkirovKirill_Lombard
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        public void Connect()
        {
            Model.BashikrovKirillLombardEntities bd = new Model.BashikrovKirillLombardEntities();
        }
        private void dtnSign_Click(object sender, RoutedEventArgs e)
        {
            if (loginField.Text == "")
            {
                MessageBox.Show("Поле логин не заполнено");
            }
            else
            {
                if (passwordField.Text == "")
                {
                    MessageBox.Show("Поле пароль не заполнено");
                }
                else
                {
                    if (DBConnection.GetContex().User.Any(a => a.Login == loginField.Text) == true)
                    {
                        var User = DBConnection.GetContex().User.Where(a => a.Login == loginField.Text).First();
                        if (User.Password == passwordField.Text)
                        {

                            MessageBox.Show("Вы авторизированы");
                        }
                        else
                        {
                            MessageBox.Show("Вы ввели неправильный пароль");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Такого пользователя не существует");
                    }
                }
            }
        }

        private void btnClear_Click_1(object sender, RoutedEventArgs e)
        {
            loginField.Clear();
            passwordField.Clear();
        }

        private void btnStat_Click(object sender, RoutedEventArgs e)
        {
            Window1 window1 = new Window1();
            window1.Show();
        }
    }
}
