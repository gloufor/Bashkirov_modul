﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BashkirovKirill_Lombard
{
    internal class DBConnection
    {
        private static Model.BashikrovKirillLombardEntities bd;
        public static Model.BashikrovKirillLombardEntities GetContex()
        {
            if (bd == null)
            {
                bd = new Model.BashikrovKirillLombardEntities();
            }
            return bd;
        }
    }
}
