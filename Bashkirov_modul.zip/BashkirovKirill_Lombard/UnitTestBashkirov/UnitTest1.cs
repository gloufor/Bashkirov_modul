﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace UnitTestBashkirov
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void login()
        {
            bool expect = true;
            bool result = MainWindow.Validation("admin", "admin");
            Assert.AreEqual(expect, result);
        }
        [TestMethod]
        public void TestAvtr()
        {
            String Login = "Admin";
            String Password = "Admin";
            bool expect = true;
            bool result = MainWindow.TestAvtr(Password, Login);
            Assert.AreEqual(expect, result);
        }
    }
}