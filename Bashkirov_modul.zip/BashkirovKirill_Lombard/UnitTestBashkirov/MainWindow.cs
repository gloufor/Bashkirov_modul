﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnitTestBashkirov
{
    internal class MainWindow
    {
        internal static bool Validation(string v1, string v2)
        {
            throw new NotImplementedException();
        }

        internal static bool TestAvtr(string password, string login)
        {
            throw new NotImplementedException();
        }
    }
}
